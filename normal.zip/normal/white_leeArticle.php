<?php

namespace Symfony\Bundle\FrameworkBundle\Tests\Fixtures\Validation;

class Article implements NotExistingInterface
{
    public $category;
}
