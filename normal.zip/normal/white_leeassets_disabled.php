<?php

$container->loadFromExtension('framework', array(
    'assets' => array(
        'enabled' => false,
    ),
));
